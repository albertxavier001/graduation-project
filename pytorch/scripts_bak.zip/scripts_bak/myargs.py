class Args(object):
    pass
